#!/bin/sh


QETOOL="/Users/kuroda/PYTHON3/QE_TOOLS/src/core"

#cp ../qe_param.json .
python3 ${QETOOL}/cif2pwin -ang-np slab_ori.cif pw.in 0.1
python3 ${QETOOL}/read_qe -in-set-mag-ele pw.in 
cp pw.in_newm pw.in
python3 ${QETOOL}/read_qe -in-set-esm-layer pw.in 0
python3 ${QETOOL}/read_qe -in-setk-hand pw.in_esml 6 8 1 0 0 0
cp pw.in_esml_newk pw.in



