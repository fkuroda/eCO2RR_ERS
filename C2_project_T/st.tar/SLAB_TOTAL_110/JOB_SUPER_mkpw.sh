#!/bin/sh

imax=1000
i=0

files=`find .  -maxdepth 1 -name  "SLAB_*"`
echo $files
for file in $files
do
 cd $file
 sub_files=`find . -maxdepth 1 -name  "*_C_*"`
 sub_files2=`find . -maxdepth 1 -name  "*_CO_*"`
 sub_files3=`find . -maxdepth 1 -name  "slab_*"`
 sub_files_all="$sub_files3 $sub_files2 $sub_files"
 for sub_file in $sub_files_all
 do
  cd $sub_file
  if [ ! -f JOB_mk_pw.sh ] && [ $i -le $imax ]; then
  pwd
  cp ../../qe_param.json .
  cp ../../JOB_mk_pw.sh .
  ./JOB_mk_pw.sh
  i=`expr $i + 1`
  echo $i
  fi
  cd ..
 done

# pwd
 cd ..

done

